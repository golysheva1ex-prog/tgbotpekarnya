# удобные импорты роутеров
from . import start_registration, address, catalog_cart, payments_demo, admin, help
