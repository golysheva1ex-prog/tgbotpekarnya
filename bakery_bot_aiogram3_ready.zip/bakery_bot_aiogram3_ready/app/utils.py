import re
from typing import Optional, Dict, Any
from app.db import db_find_product_by_sku

def normalize_phone(phone: str) -> Optional[str]:
    digits = re.sub(r"\D", "", phone or "")
    if not digits:
        return None
    if digits.startswith("8") and len(digits) == 11:
        digits = "7" + digits[1:]
    if len(digits) >= 10:
        return "+" + digits
    return None

def format_address(addr: Dict[str, Any]) -> str:
    parts = [addr.get("address_line","")]
    if addr.get("apt"): parts.append(f"кв/оф {addr['apt']}")
    if addr.get("entrance"): parts.append(f"подъезд {addr['entrance']}")
    if addr.get("floor"): parts.append(f"этаж {addr['floor']}")
    if addr.get("comment"): parts.append(f"коммент: {addr['comment']}")
    return ", ".join([p for p in parts if p])

# простая транслитерация для slug/sku
RU_MAP = {
    "а":"a","б":"b","в":"v","г":"g","д":"d","е":"e","ё":"e","ж":"zh","з":"z","и":"i","й":"i","к":"k","л":"l","м":"m",
    "н":"n","о":"o","п":"p","р":"r","с":"s","т":"t","у":"u","ф":"f","х":"h","ц":"c","ч":"ch","ш":"sh","щ":"sch",
    "ъ":"","ы":"y","ь":"","э":"e","ю":"yu","я":"ya"
}

def slugify(text: str) -> str:
    t = text.strip().lower()
    res = []
    for ch in t:
        if ch.isalnum():
            res.append(ch)
        else:
            res.append(" ")
    # заменим русские буквы
    t2 = "".join(res)
    out = []
    for ch in t2:
        out.append(RU_MAP.get(ch, ch))
    s = "".join(out)
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = re.sub(r"-+", "-", s).strip("-")
    return s

async def make_unique_sku(title: str) -> str:
    base = slugify(title) or "sku"
    sku = base
    i = 1
    while True:
        exists = await db_find_product_by_sku(sku)
        if not exists:
            return sku
        i += 1
        sku = f"{base}-{i}"
