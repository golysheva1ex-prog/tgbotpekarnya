import json
from datetime import datetime
from typing import Optional, List, Dict, Any, Tuple

import aiosqlite
from app.config import DB_PATH

CREATE_SQL = [
    """
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tg_id INTEGER UNIQUE NOT NULL,
        name TEXT NOT NULL,
        phone TEXT NOT NULL
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS addresses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        address_line TEXT NOT NULL,
        apt TEXT,
        entrance TEXT,
        floor TEXT,
        comment TEXT,
        is_default INTEGER NOT NULL DEFAULT 1,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        slug TEXT UNIQUE NOT NULL,
        title TEXT NOT NULL
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER NOT NULL,
        sku TEXT UNIQUE NOT NULL,
        title TEXT NOT NULL,
        price_minor INTEGER NOT NULL,
        available INTEGER NOT NULL DEFAULT 1,
        photo_file_id TEXT,
        FOREIGN KEY(category_id) REFERENCES categories(id)
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        status TEXT NOT NULL,
        delivery_type TEXT,
        delivery_fee_minor INTEGER NOT NULL DEFAULT 0,
        subtotal_minor INTEGER NOT NULL DEFAULT 0,
        total_minor INTEGER NOT NULL DEFAULT 0,
        address_snapshot TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        sku TEXT NOT NULL,
        title TEXT NOT NULL,
        unit_price_minor INTEGER NOT NULL,
        qty INTEGER NOT NULL DEFAULT 1,
        FOREIGN KEY(order_id) REFERENCES orders(id)
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );
    """
]

async def init_db(default_courier_fee_rub: int = 150):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA foreign_keys = ON;")
        for sql in CREATE_SQL:
            await db.execute(sql)
        # Служебная настройка
        await db.execute(
            "INSERT OR IGNORE INTO settings(key, value) VALUES('courier_fee_minor', ?)",
            (default_courier_fee_rub * 100,)
        )
        # Убедимся, что есть служебная категория "Общее"
        await db.execute(
            "INSERT OR IGNORE INTO categories(slug, title) VALUES('general','Общее')"
        )
        await db.commit()

# ------- пользователи / адреса -------
async def db_get_user_by_tg(tg_id: int) -> Optional[Dict[str, Any]]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA foreign_keys = ON;")
        cur = await db.execute("SELECT * FROM users WHERE tg_id = ?", (tg_id,))
        row = await cur.fetchone()
        return dict(row) if row else None

async def db_create_or_update_user(tg_id: int, name: str, phone: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA foreign_keys = ON;")
        await db.execute("""
            INSERT INTO users(tg_id, name, phone) VALUES(?, ?, ?)
            ON CONFLICT(tg_id) DO UPDATE SET name=excluded.name, phone=excluded.phone
        """, (tg_id, name, phone))
        await db.commit()

async def db_get_default_address(user_id: int) -> Optional[Dict[str, Any]]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA foreign_keys = ON;")
        cur = await db.execute("""
            SELECT * FROM addresses WHERE user_id = ? AND is_default = 1 ORDER BY id DESC LIMIT 1
        """, (user_id,))
        row = await cur.fetchone()
        return dict(row) if row else None

async def db_set_default_address(user_id: int, addr: Dict[str, Any]):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA foreign_keys = ON;")
        await db.execute("""
            INSERT INTO addresses(user_id, address_line, apt, entrance, floor, comment, is_default)
            VALUES(?, ?, ?, ?, ?, ?, 1)
        """, (user_id, addr.get("address_line",""), addr.get("apt",""),
              addr.get("entrance",""), addr.get("floor",""), addr.get("comment","")))
        await db.commit()

# ------- настройки -------
async def db_get_setting(key: str, default: Optional[str] = None) -> str:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA foreign_keys = ON;")
        cur = await db.execute("SELECT value FROM settings WHERE key = ?", (key,))
        row = await cur.fetchone()
        if row:
            return row["value"]
        return default or ""

async def db_set_setting(key: str, value: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA foreign_keys = ON;")
        await db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES(?, ?)", (key, value))
        await db.commit()

# ------- служебная категория -------
async def db_get_or_create_general_category_id() -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA foreign_keys = ON;")
        cur = await db.execute("SELECT id FROM categories WHERE slug = 'general' LIMIT 1")
        row = await cur.fetchone()
        if row:
            return row["id"]
        await db.execute("INSERT INTO categories(slug,title) VALUES('general','Общее')")
        await db.commit()
        cur2 = await db.execute("SELECT last_insert_rowid() AS id")
        rid = await cur2.fetchone()
        return rid["id"]

# ------- товары -------
async def db_list_products_public(page: int, page_size: int) -> Tuple[List[Dict[str, Any]], int]:
    """
    Список товаров для пользователей (available=1) + общее количество для пагинации.
    """
    offset = max(0, (page - 1) * page_size)
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA foreign_keys = ON;")
        cur = await db.execute("""
            SELECT id, sku, title, price_minor, available, photo_file_id
            FROM products
            WHERE available = 1
            ORDER BY id DESC
            LIMIT ? OFFSET ?
        """, (page_size, offset))
        rows = await cur.fetchall()
        cur2 = await db.execute("SELECT COUNT(*) AS cnt FROM products WHERE available = 1")
        total = (await cur2.fetchone())[0]
        return [dict(r) for r in rows], int(total)

async def db_list_products_admin(limit: int = 50) -> List[Dict[str, Any]]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA foreign_keys = ON;")
        cur = await db.execute("""
            SELECT p.id, p.sku, p.title, p.price_minor, p.available, p.photo_file_id
            FROM products p
            ORDER BY p.id DESC LIMIT ?
        """, (limit,))
        rows = await cur.fetchall()
        return [dict(r) for r in rows]

async def db_get_product(prod_id: int) -> Optional[Dict[str, Any]]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA foreign_keys = ON;")
        cur = await db.execute("SELECT * FROM products WHERE id = ?", (prod_id,))
        row = await cur.fetchone()
        return dict(row) if row else None

async def db_find_product_by_sku(sku: str) -> Optional[Dict[str, Any]]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA foreign_keys = ON;")
        cur = await db.execute("SELECT * FROM products WHERE sku = ?", (sku,))
        row = await cur.fetchone()
        return dict(row) if row else None

async def db_create_product(cat_id: int, title: str, price_minor: int, sku: str, available: int = 1, photo_file_id: Optional[str] = None) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA foreign_keys = ON;")
        await db.execute("""
            INSERT INTO products(category_id, sku, title, price_minor, available, photo_file_id)
            VALUES(?,?,?,?,?,?)
        """, (cat_id, sku, title, price_minor, available, photo_file_id))
        await db.commit()
        cur = await db.execute("SELECT last_insert_rowid()")
        rid = await cur.fetchone()
        return rid[0]

async def db_update_product_title(prod_id: int, title: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA foreign_keys = ON;")
        await db.execute("UPDATE products SET title = ? WHERE id = ?", (title, prod_id))
        await db.commit()

async def db_update_product_price(prod_id: int, price_minor: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA foreign_keys = ON;")
        await db.execute("UPDATE products SET price_minor = ? WHERE id = ?", (price_minor, prod_id))
        await db.commit()

async def db_set_product_available(prod_id: int, available: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA foreign_keys = ON;")
        await db.execute("UPDATE products SET available = ? WHERE id = ?", (available, prod_id))
        await db.commit()

async def db_update_product_photo(prod_id: int, photo_file_id: Optional[str]):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA foreign_keys = ON;")
        await db.execute("UPDATE products SET photo_file_id = ? WHERE id = ?", (photo_file_id, prod_id))
        await db.commit()

async def db_delete_product(prod_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA foreign_keys = ON;")
        await db.execute("DELETE FROM products WHERE id = ?", (prod_id,))
        await db.commit()

# ------- корзина / заказы -------
async def db_get_or_create_cart(user_id: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA foreign_keys = ON;")
        cur = await db.execute("SELECT id FROM orders WHERE user_id = ? AND status = 'cart' ORDER BY id DESC LIMIT 1", (user_id,))
        row = await cur.fetchone()
        if row:
            return row["id"]
        created_at = datetime.utcnow().isoformat()
        await db.execute("""
            INSERT INTO orders(user_id, status, created_at, subtotal_minor, delivery_fee_minor, total_minor)
            VALUES(?, 'cart', ?, 0, 0, 0)
        """, (user_id, created_at))
        await db.commit()
        cur2 = await db.execute("SELECT last_insert_rowid() AS id")
        row2 = await cur2.fetchone()
        return row2["id"]

async def db_add_item_to_cart(order_id: int, sku: str, title: str, unit_price_minor: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA foreign_keys = ON;")
        cur = await db.execute("SELECT id, qty FROM order_items WHERE order_id = ? AND sku = ?", (order_id, sku))
        row = await cur.fetchone()
        if row:
            await db.execute("UPDATE order_items SET qty = ? WHERE id = ?", (row["qty"] + 1, row["id"]))
        else:
            await db.execute("""
                INSERT INTO order_items(order_id, sku, title, unit_price_minor, qty)
                VALUES(?, ?, ?, ?, 1)
            """, (order_id, sku, title, unit_price_minor))
        await db.commit()

async def db_get_cart_items(order_id: int) -> List[Dict[str, Any]]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA foreign_keys = ON;")
        cur = await db.execute("SELECT * FROM order_items WHERE order_id = ?", (order_id,))
        rows = await cur.fetchall()
        return [dict(r) for r in rows]

async def db_update_order_totals(order_id: int, delivery_fee_minor: int = 0):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA foreign_keys = ON;")
        cur = await db.execute("SELECT unit_price_minor, qty FROM order_items WHERE order_id = ?", (order_id,))
        items = await cur.fetchall()
        subtotal = sum(x["unit_price_minor"] * x["qty"] for x in items)
        total = subtotal + delivery_fee_minor
        await db.execute("""
            UPDATE orders SET subtotal_minor = ?, delivery_fee_minor = ?, total_minor = ? WHERE id = ?
        """, (subtotal, delivery_fee_minor, total, order_id))
        await db.commit()

async def db_set_order_checkout(order_id: int, delivery_type: str, address_snapshot: Optional[Dict[str, Any]]):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA foreign_keys = ON;")
        await db.execute("""
            UPDATE orders
            SET status = 'confirming',
                delivery_type = ?,
                address_snapshot = ?
            WHERE id = ?
        """, (delivery_type, json.dumps(address_snapshot or {}), order_id))
        await db.commit()

async def db_get_order_basic(order_id: int) -> Optional[Dict[str, Any]]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA foreign_keys = ON;")
        cur = await db.execute("SELECT * FROM orders WHERE id = ?", (order_id,))
        row = await cur.fetchone()
        return dict(row) if row else None

async def db_get_user_active_orders(limit: int = 20) -> List[Dict[str, Any]]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA foreign_keys = ON;")
        cur = await db.execute("""
            SELECT o.*, u.name, u.phone, u.tg_id
            FROM orders o
            JOIN users u ON u.id = o.user_id
            WHERE o.status IN ('confirming','preparing','delivering')
            ORDER BY o.id DESC LIMIT ?
        """, (limit,))
        rows = await cur.fetchall()
        return [dict(r) for r in rows]

async def db_set_order_status(order_id: int, status: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA foreign_keys = ON;")
        await db.execute("UPDATE orders SET status = ? WHERE id = ?", (status, order_id))
        await db.commit()

async def db_clear_cart(order_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA foreign_keys = ON;")
        await db.execute("DELETE FROM order_items WHERE order_id = ?", (order_id,))
        await db.execute("UPDATE orders SET subtotal_minor=0, delivery_fee_minor=0, total_minor=0 WHERE id = ?", (order_id,))
        await db.commit()
